# Fold and Flip — design handoff

Start with `DESIGN.md`. It is the spec. Everything else here is reference.

## screens/

The final design-canvas artboards, one file per screen and size. They are
**reference source, not runnable pages**: they were written for the design
canvas runtime, so opening them directly will show raw `{{…}}` placeholders
and `<sc-if>` / `<sc-for>` tags. Read them for exact markup, inline styles,
colours, spacing, copy and pixel-art SVG. The `<script>` block at the bottom
of each file holds the interaction logic: grid states, Area, Selection
toggle, Reveal popover, share-link copy, mobile menu and logo flip.

| File | Route / role |
| --- | --- |
| Pixel-Landing(-Tablet/-Mobile) | `/welcome` |
| Pixel-Landing-Mobile-Menu | `/welcome`, mobile menu open |
| Pixel-Create(-Tablet/-Mobile) | `/new` |
| Pixel-Join(-Tablet/-Mobile) | `/:id/join` |
| Pixel-Session(-Tablet/-Mobile) | `/:id/start` (Admin; `share` prop picks bar/header/window) |
| Pixel-Session-Ended(-Tablet/-Mobile) | `/:id/ended` (Reveal) |
| FF-Error-C(-Tablet/-Mobile) | not found / connection lost / error (`kind` prop) |
| FF-Loaders | loader spec (option C chosen) |
| FF-Tooltips, FF-Palettes, FF-Logo, FF-Spotlight(-Mobile), Pixel-HeroFonts | spec boards |

Values inside `{{…}}` resolve from the script: palette `grape`, hero font
`bungee`, logo mark `card`.

## sprites/

Every pixel-art sprite as a standalone SVG, 8 px per art pixel, with the white
sticker outline baked in. They use `shape-rendering="crispEdges"`, so scale
them by whole multiples. The floating drop shadow is applied in CSS
(`filter: drop-shadow(3px 3px 0 rgba(30,27,46,.18))`). Logo files:
`logo-card.svg` is the chosen mark and `logo-card-back-blank.svg` is the back
face for the flip.

The live canvas: https://claude.ai/artifact/B8xUuTAY1pmHCQcMD5FKRc (page
"Round 6 · Fold and Flip"). It's private to your claude.ai account, so Claude
Code can't open it; take screenshots from it for visual reference.
